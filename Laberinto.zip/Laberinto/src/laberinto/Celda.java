package laberinto;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Celda extends JPanel
{
	public static final int SIZE = 50;
	public static final int TOP=0, RIGHT=1, BOTTOM=2, LEFT=3;
	private boolean[] muro = {true, true, true , true};
	
	private int row, col;
	
	public Celda(int fila, int col)
	{
		this.row=fila;
		this.col=col;
	}
	
	public int getRow() {
		return row;
	}
	public int getCol() {
		return col;
	}
	
	public void quitarMuro(int lado)
	{
		muro[lado]=false; 
	}
	
	public boolean hayMuro(int lado)
	{
		return muro[lado];
	}
	public void paintComponent(Graphics g)
	{
		// dibujar celda
		
		g.setColor(Color.WHITE);
		g.drawRect(0, 0, SIZE, SIZE);
//		g.setColor(Color.WHITE);
		g.setColor(Color.BLACK);
//		g.fillRect(1, 1, SIZE-1, SIZE-1);
		
		//dibbujar muro
		if(muro[TOP])
		{
			g.drawLine(0, 0, SIZE, 0);
		}
		if(muro[LEFT])
		{
			g.drawLine(0, 0, 0, SIZE);
		}
		//dibujar circulo verde
		/*g.setColor(Color.GREEN);
		g.fillOval(3, 3, SIZE-6, SIZE-6);
		
		//dibujar circulo rojo
		g.setColor(Color.RED);
		g.fillOval(3, 3, SIZE-6, SIZE-6);*/
		
	}
	public Dimension getPreferredSize()
	{if(vecina.getRow()<row)
	{
		quitarMuro(TOP);
		vecina.quitarMuro(BOTTOM);
	}
		Dimension size= new Dimension(SIZE, SIZE);
		return size;
	}
	
	public boolean isAllMuros()
	{
		return muro[TOP]&&muro[RIGHT]&&muro[BOTTOM]&&muro[LEFT];
	}
	
	public void abrirCamino(Celda vecina)
	{
		if(vecina.getRow()<row)
		{
			quitarMuro(TOP);
			vecina.quitarMuro(BOTTOM);
		}
		if(vecina.getRow()>row)
		{
			quitarMuro(TOP);
			vecina.quitarMuro(BOTTOM);
		}
		if(vecina.getRow()<row)
		{
			quitarMuro(TOP);
			vecina.quitarMuro(BOTTOM);
		}
		if(vecina.getRow()<row)
		{
			quitarMuro(TOP);
			vecina.quitarMuro(BOTTOM);
		}
	}
	
}
