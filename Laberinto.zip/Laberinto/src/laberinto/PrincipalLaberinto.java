package laberinto;

public class PrincipalLaberinto {

	public static void main(String[] args) {
		// TODO Apéndice de método generado automáticamente
		Laberinto vista = new Laberinto();
		vista.setDefaultCloseOperation(vista.EXIT_ON_CLOSE);
		

	}

}
