package laberinto;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Laberinto extends JFrame
{
	public static final int SIZE = 5;
	private Celda[][] celdas;
	private JPanel malla;
	
	
	public Laberinto()
	{
		initGUI();
		
		setTitle("laberinto");
		setLocationRelativeTo(null);
		pack();
		setVisible(true);
		setResizable(true);
	}
	public void initGUI()
	{
		initLaberinto();
		add(malla, BorderLayout.CENTER);
		
	}
	private void initLaberinto()
	{
		malla = new JPanel();
		malla.setLayout(new GridLayout(SIZE, SIZE));
		
		celdas = new Celda[SIZE][SIZE];
		
		for (int fila=0; fila <SIZE; fila++)
		{
			for (int col=0; col<SIZE; col++)
			{
				celdas[fila][col]= new Celda (fila,col);
				malla.add(celdas[fila][col]);
			}
		}
		
		generarLaberinto();
	}
	
	
	private void generarLaberinto()
	{
		Random aleatorio = new Random();
		int fila=aleatorio.nextInt(SIZE);
		int col=aleatorio.nextInt(SIZE);
		
		int celdasTotales=SIZE*SIZE;
		int visitadas = 1;
		
		ArrayList<Celda> celdasVisitar= new ArrayList <Celda>();
		
		while(visitadas<celdasTotales)
		{
			ArrayList<Celda> vecinasDisponibles = new ArrayList<Celda>();
			//buscar vecinas disponibles TOP
			if(this.isAvailable(fila-1, col))
			{
				vecinasDisponibles.add(celdas[fila-1][col]);
			}
			//buscar vecinas disponibles BOTTOM 
			if(this.isAvailable(fila+1, col))
			{
				vecinasDisponibles.add(celdas[fila+1][col]);
			}
			//buscar vecinas disponibles RIGHT
			if(this.isAvailable(fila, col+1))
			{
				vecinasDisponibles.add(celdas[fila][col+1]);
			}
			//buscar vecinas disponibles LEFT
			if(this.isAvailable(fila, col-1))
			{
				vecinasDisponibles.add(celdas[fila][col-1]);
			}
			if(vecinasDisponibles.size()>0)
			{
				if(vecinasDisponibles.size()>1)
				{
					celdasVisitar.add(celdas[fila][col]);
				}
				//sacar celda aleatorio de las vecinas disponibles
				int index= aleatorio.nextInt(vecinasDisponibles.size());
				Celda vecina=vecinasDisponibles.get(index);
				
				//abrir camino entre celdas
				celdas[fila][col].abrirCamino(vecina);
				fila = vecina.getRow();
				col= vecina.getCol();
				visitadas++;
			}
			else
			{
				if(celdasVisitar.size()>0)
				{
					Celda actual = celdasVisitar.get(0);
					fila=actual.getRow();
					col=actual.getCol();
				}
			}
			
		}
	}
	
	private boolean isAvailable(int fila, int col)
	{
		return celdas [fila][col].isAllMuros()&&fila>0&&fila<SIZE&&col>0&&col<SIZE;
	}

}
